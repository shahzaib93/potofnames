module.exports = {
  reactStrictMode: true,
  env: {
    MONGODB_URI: "mongodb+srv://shahzaib:Daata321@cluster0.tosar.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    MONGODB_DB: "myFirstDatabase",
    GOOGLE_CLIENT_ID:"907201814402-dvksigsadp7ch5bhcf7lfoo17ubomo52.apps.googleusercontent.com",
    GOOGLE_CLIENT_SECRET:"5aiF9wQkZ7u__hoF2CTHFvVJ",
    NEXTAUTH_URL:"https://potofnames.com/"
    // NEXTAUTH_URL:"http://localhost:3000/"
  }
}