module.exports = {
  reactStrictMode: true,
  env: {
    MONGODB_URI: "mongodb+srv://shahzaib:Daata321@cluster0.tosar.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    MONGODB_DB: "myFirstDatabase"
  }
}